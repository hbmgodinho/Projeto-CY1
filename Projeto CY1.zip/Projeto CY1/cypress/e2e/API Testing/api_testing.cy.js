/// <reference types="cypress"/>


describe('API Testing', () => {
    it('Electronics Filter', () => {
      cy.request('https://fakestoreapi.com/products').then((response) => {
        expect(response.status).to.equal  (200)
        const electronicsProducts = response.body.filter((product) => product.category === 'electronics')
        cy.log('Electronic Products:', electronicsProducts)
        expect(electronicsProducts.length).to.be.greaterThan(4)
        electronicsProducts.forEach((product) => {
          cy.log(`Product: ${product.title} - Price: ${product.price}`)
    })
    })
})
})
