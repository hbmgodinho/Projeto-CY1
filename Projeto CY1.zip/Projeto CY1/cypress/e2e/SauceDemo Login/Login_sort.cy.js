/// <reference types="cypress"/>


describe('Login and Sort Change', () => {

    it('passes', () => {
        
        cy.visit('https://www.saucedemo.com/')
        cy.get('[data-test="username"]').type('standard_user')
        cy.get('[data-test="password"]').type('secret_sauce')
        cy.get('[data-test="login-button"]').click()
        cy.get('[data-test="product-sort-container"]').select('za')
        cy.get('[data-test="item-3-title-link"] > [data-test="inventory-item-name"]').first().should('have.text', 'Test.allTheThings() T-Shirt (Red)')
    });
});